package org.ifundip.mobileirs

const val SERVER_PORT = 8080